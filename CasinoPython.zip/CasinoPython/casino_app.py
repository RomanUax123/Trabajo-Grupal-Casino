import pygame
import random
import sys
import json
import os
import time
import pathlib
import math

# Inicializar Pygame
pygame.init()

# --- 1. CONFIGURACIÓN INICIAL Y GLOBAL ---

ANCHO = 1200
ALTO = 800
VENTANA = pygame.display.set_mode((ANCHO, ALTO))
pygame.display.set_caption("Casino Uax") 
clock = pygame.time.Clock()

# Colores, Fuentes, y Variables globales
NEGRO = (0, 0, 0)
BLANCO = (255, 255, 255)
VERDE_MESA = (0, 70, 0)
ROJO_R = (255, 0, 0) 
NEGRO_R = (50, 50, 50) 
DORADO = (255, 215, 0)
ROJO_BTN = (200, 0, 0)
VERDE_BTN = (0, 150, 0)
GRIS_BTN = (100, 100, 100)

try:
    FUENTE_TITULO = pygame.font.Font(None, 90)
    FUENTE_MENU = pygame.font.Font(None, 50)
    FUENTE_JUEGO = pygame.font.Font(None, 35)
    FUENTE_SMALL = pygame.font.Font(None, 25)
    FUENTE_INPUT = pygame.font.SysFont('Arial', 30) 
except:
    FUENTE_TITULO = pygame.font.SysFont('Arial', 90, bold=True)
    FUENTE_MENU = pygame.font.SysFont('Arial', 50)
    FUENTE_JUEGO = pygame.font.SysFont('Arial', 35)
    FUENTE_SMALL = pygame.font.SysFont('Arial', 25)
    FUENTE_INPUT = pygame.font.SysFont('Arial', 30)

estado_juego = 'login'
usuario_actual = None
ANIMACION_ACTIVA = False 

ruleta_angulo = 0
ruleta_velocidad = 0
ruleta_color_fondo = DORADO
ruleta_msg = "Coloca tus fichas y gira."

MAPEO_VALOR = {'2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, '10': 10, 'Jack': 10, 'Queen': 10, 'King': 10, 'Ace': 11}
FICHA_VALORES = {1: 1, 5: 5, 10: 10, 25: 25, 100: 100}
FICHA_CICLO = [1, 5, 10, 25, 100]

# Objetos globales de entrada de texto (Inicializados en main)
user_box_login = None
pass_box_login = None
login_message = ""


# --- 2. SISTEMA DE PERSISTENCIA (JSON) ---

RUTA_USUARIOS = 'usuarios.json'
FONDO_INICIAL = 1000 
FONDO_OWNER = 100000000000 
CONTRASENA_OWNER = "soy yo"

def cargar_usuarios():
    if not os.path.exists(RUTA_USUARIOS):
        usuarios = {
            "Owner": {"password": CONTRASENA_OWNER, "balance": FONDO_OWNER, "isAdmin": True} 
        }
        guardar_usuarios(usuarios)
        return usuarios
    
    try:
        with open(RUTA_USUARIOS, 'r') as f:
            return json.load(f)
    except json.JSONDecodeError:
        print("ERROR CRÍTICO: El archivo usuarios.json está corrupto. Creando uno nuevo.")
        return {"Owner": {"password": CONTRASENA_OWNER, "balance": FONDO_OWNER, "isAdmin": True}}

def guardar_usuarios(usuarios):
    with open(RUTA_USUARIOS, 'w') as f:
        json.dump(usuarios, f, indent=4)

def registrar_usuario(username, password):
    usuarios = cargar_usuarios()
    if username in usuarios:
        return False, "Ese usuario ya existe."
    
    usuarios[username] = {"password": password, "balance": FONDO_INICIAL, "isAdmin": False}
    guardar_usuarios(usuarios)
    return True, "Registro exitoso. ¡Empiezas con 1000€!"

def iniciar_sesion(username, password):
    usuarios = cargar_usuarios()
    if username not in usuarios:
        return False, "Usuario no encontrado."
    
    # Acceso Owner
    if username == "Owner" and password == CONTRASENA_OWNER:
         return True, "Acceso de Owner concedido."
         
    # Acceso de usuario normal
    if usuarios[username]["password"] != password:
        return False, "Contraseña incorrecta."
        
    return True, f"Bienvenido, {username}."


# --- 3. GESTIÓN DE RECURSOS GRÁFICOS ---

RECURSOS = {}
CARTA_W, CARTA_H = 80, 115 
FICHA_W, FICHA_H = 40, 40 

RUTA_BASE = pathlib.Path(__file__).parent 

def cargar_imagen(filename, scale=None):
    filepath = RUTA_BASE / 'assets' / filename 
    
    if not filepath.exists():
        base, ext = os.path.splitext(filename)
        filepath_upper = RUTA_BASE / 'assets' / (base + ext.upper())
        filename_capital = filename.capitalize()
        filepath_capital = RUTA_BASE / 'assets' / filename_capital
        
        if filepath_upper.exists():
            filepath = filepath_upper
        elif filepath_capital.exists():
            filepath = filepath_capital
        else:
            print("\n\n" + "="*80)
            raise FileNotFoundError(f"¡ERROR CRÍTICO! FALTA EL ARCHIVO: {filepath.as_posix()}.")
            print("="*80 + "\n\n")

    try:
        img = pygame.image.load(str(filepath)).convert_alpha()
    except pygame.error as e:
        print(f"ERROR DE FORMATO DE IMAGEN: Pygame falló al cargar {filename}. El archivo puede estar corrupto o no es un PNG válido. Detalles: {e}")
        sys.exit() 

    if scale:
        img = pygame.transform.scale(img, scale)
    return img

def cargar_recursos():
    global RECURSOS
    try:
        # Fichas 
        RECURSOS['fichas'] = {}
        for valor in [1, 5, 10, 25, 100]:
            RECURSOS['fichas'][valor] = cargar_imagen(f'ficha_{valor}.png', (FICHA_W, FICHA_H))
        
        # Ruleta
        RECURSOS['ruleta_wheel'] = cargar_imagen('ruleta_wheel.png', (500, 500))
        RECURSOS['fondo_menu'] = cargar_imagen('fondo_menu_principal.png', (ANCHO, ALTO))
        RECURSOS['fondo_ruleta'] = cargar_imagen('fondo_ruleta.png', (ANCHO, ALTO))
        
        # Blackjack / Poker
        RECURSOS['fondo_blackjack'] = cargar_imagen('fondo_blackJack.png', (ANCHO, ALTO)) 
        RECURSOS['fondo_poker'] = cargar_imagen('fondo_poker.png', (ANCHO, ALTO)) 
        
        # Cartas
        RECURSOS['back'] = cargar_imagen('back.png', (CARTA_W, CARTA_H))
        RECURSOS['cartas'] = {}
        palos = ['clubs', 'diamonds', 'hearts', 'spades']
        valores = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'Jack', 'Queen', 'King', 'Ace']

        for val_nombre in valores:
            for palo_nombre in palos:
                key = f"{val_nombre}_of_{palo_nombre}"
                RECURSOS['cartas'][key] = cargar_imagen(f'{key}.png', (CARTA_W, CARTA_H))
                
        # Símbolos de Tragaperras
        RECURSOS['slots'] = {}
        RECURSOS['slots']['cherry'] = cargar_imagen('simbolo_cherry.png', (100, 100))
        RECURSOS['slots']['lemon'] = cargar_imagen('simbolo_lemon.png', (100, 100))
        RECURSOS['slots']['bell'] = cargar_imagen('simbolo_bell.png', (100, 100))
        RECURSOS['slots']['bar'] = cargar_imagen('simbolo_bar.png', (100, 100))
        RECURSOS['slots']['melon'] = cargar_imagen('simbolo_melon.png', (100, 100)) 
        RECURSOS['slots']['seven'] = cargar_imagen('simbolo_seven.png', (100, 100))
                
        print("¡Todos los recursos gráficos cargados correctamente! La ventana se abrirá ahora.")
        
    except FileNotFoundError as e:
        print(f"\n\nERROR CRÍTICO DE ARCHIVO DETECTADO: {e}")
        print("El programa se cerrará. VERIFICA que los archivos de imagen existen en la carpeta 'assets/'.\n")
        sys.exit()

cargar_recursos()

# --- 4. CLASES BÁSICAS DE JUEGO ---

class Boton:
    def __init__(self, x, y, ancho, alto, color_normal, color_hover, texto, funcion, font=FUENTE_MENU):
        self.rect = pygame.Rect(x, y, ancho, alto)
        self.color_normal = color_normal
        self.color_hover = color_hover
        self.texto = texto
        self.funcion = funcion
        self.font = font

    def dibujar(self, superficie):
        color = self.color_normal
        if self.rect.collidepoint(pygame.mouse.get_pos()):
            color = self.color_hover
        
        pygame.draw.rect(superficie, color, self.rect, border_radius=10)
        
        texto_render = self.font.render(self.texto, True, BLANCO)
        texto_rect = texto_render.get_rect(center=self.rect.center)
        superficie.blit(texto_render, texto_rect)

    def clic(self, evento):
        if evento.type == pygame.MOUSEBUTTONDOWN and evento.button == 1:
            if self.rect.collidepoint(evento.pos):
                self.funcion()
                return True
        return False

class Mazo:
    def __init__(self):
        self.cartas = []
        palos = ['clubs', 'diamonds', 'hearts', 'spades']
        valores_nombre = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'Jack', 'Queen', 'King', 'Ace']

        for val_nombre in valores_nombre:
            val_num = MAPEO_VALOR[val_nombre]
            for palo_nombre in palos:
                self.cartas.append((val_num, f"{val_nombre}_of_{palo_nombre}")) 
        random.shuffle(self.cartas)

    def repartir_carta(self):
        if not self.cartas:
            self.__init__()
        return self.cartas.pop()
        
def calcular_puntuacion(mano):
    puntos = sum(valor for valor, nombre in mano)
    num_ases = sum(1 for valor, nombre in mano if 'Ace' in nombre)

    while puntos > 21 and num_ases > 0:
        puntos -= 10
        num_ases -= 1
    return puntos


class Usuario:
    def __init__(self, username, balance, isAdmin):
        self.username = username
        self.balance = balance
        self.isAdmin = isAdmin
        
    def deduct_balance(self, amount):
        if self.balance >= amount:
            self.balance -= amount
            return True
        return False
        
    def add_balance(self, amount):
        self.balance += amount
        
def set_usuario_actual(username):
    global usuario_actual
    
    usuarios_global = cargar_usuarios()
    datos = usuarios_global.get(username, {})
    
    if not datos:
        return
        
    usuario_actual = Usuario(username, datos.get("balance", 0), datos.get("isAdmin", False))
    
def guardar_saldo_actual():
    if usuario_actual and usuario_actual.username != "Owner":
        usuarios = cargar_usuarios()
        usuarios[usuario_actual.username]["balance"] = usuario_actual.balance
        guardar_usuarios(usuarios)

# --- Entrada de texto para Login (Nueva Clase) ---

class TextBox:
    def __init__(self, x, y, w, h, text=''):
        self.rect = pygame.Rect(x, y, w, h)
        self.color = BLANCO
        self.text = text
        self.txt_surface = FUENTE_INPUT.render(text, True, NEGRO)
        self.active = False
        self.password_mode = False

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            if self.rect.collidepoint(event.pos):
                self.active = True
            else:
                self.active = False
            self.color = DORADO if self.active else BLANCO
        
        if event.type == pygame.KEYDOWN:
            if self.active:
                if event.key == pygame.K_RETURN:
                    self.active = False
                elif event.key == pygame.K_BACKSPACE:
                    self.text = self.text[:-1]
                else:
                    self.text += event.unicode
                self.txt_surface = FUENTE_INPUT.render('*' * len(self.text) if self.password_mode else self.text, True, NEGRO)

    def draw(self, screen):
        # Dibujar fondo blanco
        pygame.draw.rect(screen, BLANCO, self.rect)
        # Dibujar borde (activo o normal)
        pygame.draw.rect(screen, self.color, self.rect, 2)
        # Dibujar texto
        screen.blit(self.txt_surface, (self.rect.x + 5, self.rect.y + 5))

    def set_password_mode(self, value):
        self.password_mode = value
        self.txt_surface = FUENTE_INPUT.render('*' * len(self.text) if self.password_mode else self.text, True, NEGRO)


# --- Funciones de navegación (sin cambios) ---
def ir_a_menu():
    global estado_juego
    estado_juego = 'menu'
    
def ir_a_login():
    global estado_juego
    estado_juego = 'login'

def ir_a_blackjack():
    global estado_juego
    estado_juego = 'blackjack'
    bj_juego.nueva_partida()

def ir_a_poker():
    global estado_juego
    estado_juego = 'poker'
    poker_juego.nueva_partida()

def ir_a_ruleta():
    global estado_juego
    estado_juego = 'ruleta'
    ruleta_juego.reiniciar()
    
def ir_a_tragaperras():
    global estado_juego
    estado_juego = 'tragaperras'
    slots_juego.reiniciar()

def depositar_dinero_demo():
    if not usuario_actual: return
    monto = 100
    usuario_actual.add_balance(monto)
    guardar_saldo_actual()
    print(f"DEPÓSITO: {monto}€ añadido. Saldo: {usuario_actual.balance}€")

boton_volver_menu = Boton(20, 20, 150, 50, ROJO_BTN, (255, 0, 0), "Volver", ir_a_menu, font=FUENTE_JUEGO)


# --- 5. LÓGICA DEL BLACKJACK CON ANIMACIÓN ---

class Blackjack:
    # ... (Clase Blackjack omitida) ...
    def __init__(self):
        self.mazo = Mazo()
        self.jugador = []
        self.crupier = []
        self.resultado = "Presiona 'Nueva Partida'"
        self.jugando = False
        self.apuesta = 0
        self.apuesta_default = 100
        self.animacion_reparto = None 

    def nueva_partida(self):
        global ANIMACION_ACTIVA
        if ANIMACION_ACTIVA: return

        if not usuario_actual or not usuario_actual.deduct_balance(self.apuesta_default):
            self.resultado = "Fondos insuficientes (Mínimo 100€)."
            return

        self.mazo = Mazo()
        self.jugador = []
        self.crupier = []
        self.apuesta = self.apuesta_default
        guardar_saldo_actual()

        self.resultado = "Juego en curso..."
        self.jugando = True
        
        self.animacion_reparto = RepartoAnimacion(self)
        ANIMACION_ACTIVA = True
        
    def check_blackjack(self):
        if calcular_puntuacion(self.jugador) == 21:
            self.resultado = "¡Blackjack! El jugador gana automáticamente."
            self.terminar_juego()
        
    def pedir_carta(self):
        global ANIMACION_ACTIVA
        if not self.jugando or ANIMACION_ACTIVA: return
        
        carta = self.mazo.repartir_carta()
        self.animacion_reparto = RepartoAnimacion(self, carta_extra=carta, es_jugador=True)
        ANIMACION_ACTIVA = True

    def plantarse(self):
        global ANIMACION_ACTIVA
        if not self.jugando or ANIMACION_ACTIVA: return
        
        self.jugando = False
        self.animacion_reparto = RepartoAnimacion(self, turno_crupier=True)
        ANIMACION_ACTIVA = True

    def check_resultado(self):
        p_jugador = calcular_puntuacion(self.jugador)
        p_crupier = calcular_puntuacion(self.crupier)
        
        if p_jugador > 21: return "¡Te pasaste de 21! Perdiste.", -self.apuesta
        if p_crupier > 21: return "¡El Crupier se pasa! ¡Ganaste!", self.apuesta
        if p_jugador > p_crupier: return "¡Ganaste!", self.apuesta
        if p_jugador < p_crupier: return "¡Perdiste!", -self.apuesta
        return "¡Empate! Dinero devuelto.", 0
        
    def terminar_juego(self):
        if not self.jugando: return
        
        self.jugando = False
        self.resultado, ganancia = self.check_resultado()
        
        if ganancia > 0: usuario_actual.add_balance(self.apuesta * 2)
        elif ganancia == 0: usuario_actual.add_balance(self.apuesta)
        
        guardar_saldo_actual()

class RepartoAnimacion:
    # ... (Clase RepartoAnimacion omitida) ...
    def __init__(self, juego_bj, carta_extra=None, es_jugador=True, turno_crupier=False):
        self.juego = juego_bj
        self.turno_crupier = turno_crupier
        self.cartas_a_repartir = []
        
        self.tiempo_inicio = time.time()
        self.duracion_por_carta = 0.35 
        self.pos_actual = (0, 0) # Inicialización segura
        self.carta_movimiento = None

        if carta_extra:
            self.cartas_a_repartir.append({'carta': carta_extra, 'destino': 'jugador' if es_jugador else 'crupier'})
        elif not turno_crupier:
            for i in range(2):
                self.cartas_a_repartir.append({'carta': self.juego.mazo.repartir_carta(), 'destino': 'jugador'})
                self.cartas_a_repartir.append({'carta': self.juego.mazo.repartir_carta(), 'destino': 'crupier'})
        
        self.indice_actual = 0
        self.pos_inicio = (ANCHO // 2 - 40, ALTO - 100)
        
        if self.cartas_a_repartir:
            self.iniciar_movimiento()

    def iniciar_movimiento(self):
        if self.indice_actual < len(self.cartas_a_repartir):
            data = self.cartas_a_repartir[self.indice_actual]
            
            mano = self.juego.jugador if data['destino'] == 'jugador' else self.juego.crupier
            destino_x = 150 + len(mano) * (CARTA_W + 15)
            destino_y = 280 if data['destino'] == 'jugador' else 80
            
            self.pos_final = (destino_x, destino_y)
            self.tiempo_movimiento = time.time()
            self.carta_movimiento = data['carta']
        else:
            self.terminar_secuencia()

    def actualizar(self):
        global ANIMACION_ACTIVA
        if not self.carta_movimiento:
            if self.turno_crupier:
                if calcular_puntuacion(self.juego.crupier) < 17:
                    carta = self.juego.mazo.repartir_carta()
                    self.cartas_a_repartir.append({'carta': carta, 'destino': 'crupier'})
                    self.indice_actual = len(self.cartas_a_repartir) - 1
                    self.iniciar_movimiento()
                    return
                else:
                    self.terminar_secuencia()
                    return
            else:
                self.terminar_secuencia()
                return

        elapsed = time.time() - self.tiempo_movimiento
        progress = min(1.0, elapsed / self.duracion_por_carta)
        
        if progress < 1.0:
            x = self.pos_inicio[0] + (self.pos_final[0] - self.pos_inicio[0]) * progress
            y = self.pos_inicio[1] + (self.pos_final[1] - self.pos_inicio[1]) * progress
            self.pos_actual = (x, y)
        else:
            data = self.cartas_a_repartir[self.indice_actual]
            if data['destino'] == 'jugador':
                self.juego.jugador.append(self.carta_movimiento)
            else:
                self.juego.crupier.append(self.carta_movimiento)
            
            self.carta_movimiento = None
            self.indice_actual += 1
            
            if self.indice_actual < len(self.cartas_a_repartir):
                self.iniciar_movimiento() 
            else:
                self.terminar_secuencia()

    def dibujar(self, superficie):
        if self.carta_movimiento:
            carta_key = self.carta_movimiento[1]
            imagen = RECURSOS['cartas'].get(carta_key)
            superficie.blit(imagen, self.pos_actual)
            
    def terminar_secuencia(self):
        global ANIMACION_ACTIVA
        self.carta_movimiento = None
        ANIMACION_ACTIVA = False
        
        if not self.turno_crupier:
            self.juego.check_blackjack()
        elif self.turno_crupier:
            self.juego.terminar_juego()
            
        self.juego.animacion_reparto = None


bj_juego = Blackjack()

# --- 6. IMPLEMENTACIÓN DEL PÓKER (VS 2 BOTS) ---

# Nueva Clase de Animación para Poker 
class RepartoAnimacionPoker:
    # ... (Clase RepartoAnimacionPoker omitida) ...
    def __init__(self, juego_poker, cartas_comunitarias=False):
        self.juego = juego_poker
        self.cartas_a_repartir = []
        self.tiempo_inicio = time.time()
        self.duracion_por_carta = 0.35
        self.pos_inicio = (ANCHO // 2 - 40, ALTO - 100)
        self.indice_actual = 0
        self.carta_movimiento = None
        self.cards_dealt = 0 
        self.pos_actual = (0, 0) # Inicialización segura

        if cartas_comunitarias:
            num_cartas = 3 if juego_poker.fase == 'Pre-Flop' else 1
            for _ in range(num_cartas):
                 self.cartas_a_repartir.append({'carta': juego_poker.mazo.repartir_carta(), 'destino': 'comunitaria'})
        else:
            for _ in range(2):
                for jugador in juego_poker.manos:
                    self.cartas_a_repartir.append({'carta': juego_poker.mazo.repartir_carta(), 'destino': jugador})
        
        if self.cartas_a_repartir:
            self.iniciar_movimiento()

    def iniciar_movimiento(self):
        if self.indice_actual < len(self.cartas_a_repartir):
            data = self.cartas_a_repartir[self.indice_actual]
            
            if data['destino'] == 'comunitaria':
                destino_x = ANCHO // 2 - 5 * (CARTA_W + 15) / 2 + len(self.juego.comunitarias) * (CARTA_W + 15)
                destino_y = 250
            elif data['destino'] == 'Jugador':
                destino_x = ANCHO // 2 - 2 * (CARTA_W + 15) / 2 + len(self.juego.manos['Jugador']) * (CARTA_W + 15)
                destino_y = 550
            else:
                 destino_x = 50 + self.cards_dealt * 20 if data['destino'] == 'Bot1' else ANCHO - 50 - 2*CARTA_W + self.cards_dealt * 20
                 destino_y = 250
            
            self.pos_final = (destino_x, destino_y)
            self.tiempo_movimiento = time.time()
            self.carta_movimiento = data['carta']
        else:
            self.terminar_secuencia()

    def actualizar(self):
        global ANIMACION_ACTIVA
        if not self.carta_movimiento:
            self.terminar_secuencia()
            return

        elapsed = time.time() - self.tiempo_movimiento
        progress = min(1.0, elapsed / self.duracion_por_carta)
        
        if progress < 1.0:
            x = self.pos_inicio[0] + (self.pos_final[0] - self.pos_inicio[0]) * progress
            y = self.pos_inicio[1] + (self.pos_final[1] - self.pos_inicio[1]) * progress
            self.pos_actual = (x, y)
        else:
            data = self.cartas_a_repartir[self.indice_actual]
            
            if data['destino'] == 'comunitaria':
                self.juego.comunitarias.append(self.carta_movimiento)
            elif data['destino'] == 'Jugador':
                self.juego.manos['Jugador'].append(self.carta_movimiento)
            elif data['destino'] == 'Bot1':
                self.juego.manos['Bot1'].append(self.carta_movimiento)
                self.cards_dealt = 1 if len(self.juego.manos['Bot1']) == 1 else 0
            elif data['destino'] == 'Bot2':
                 self.juego.manos['Bot2'].append(self.carta_movimiento)
                 self.cards_dealt = 1 if len(self.juego.manos['Bot2']) == 1 else 0

            self.carta_movimiento = None
            self.indice_actual += 1
            self.iniciar_movimiento() 
            
    def dibujar(self, superficie):
        if self.carta_movimiento:
            carta_key = self.carta_movimiento[1]
            imagen = RECURSOS['cartas'].get(carta_key)
            superficie.blit(imagen, self.pos_actual)
            
    def terminar_secuencia(self):
        global ANIMACION_ACTIVA
        self.carta_movimiento = None
        ANIMACION_ACTIVA = False

class Poker:
    # ... (Clase Poker omitida) ...
    def __init__(self):
        self.mazo = Mazo()
        self.manos = {'Jugador': [], 'Bot1': [], 'Bot2': []}
        self.comunitarias = []
        self.jugando = False
        self.fase = 'Resultado' 
        self.resultado = "Presiona 'Nueva Partida'"
        self.apuesta = 100 
        self.apuesta_actual_ronda = 0
        self.bote = 300 
        self.animacion_reparto = None
        self.jugadores_activos = ['Jugador', 'Bot1', 'Bot2']
        self.turno = 'Jugador' 

    def nueva_partida(self):
        global ANIMACION_ACTIVA
        if self.jugando or ANIMACION_ACTIVA: return
        
        if not usuario_actual or not usuario_actual.deduct_balance(self.apuesta):
            self.resultado = "Fondos insuficientes (100€)."
            return
            
        self.mazo = Mazo()
        self.manos = {'Jugador': [], 'Bot1': [], 'Bot2': []}
        self.comunitarias = []
        self.jugando = True
        self.fase = 'Reparto' # Nueva fase de reparto animado
        self.resultado = "Repartiendo cartas iniciales..."
        self.apuesta_actual_ronda = self.apuesta # Ciega Grande
        self.bote = self.apuesta * 3
        self.jugadores_activos = ['Jugador', 'Bot1', 'Bot2']
        self.turno = 'Jugador'
        guardar_saldo_actual()

        # Iniciar animación de reparto de 6 cartas a los jugadores
        self.animacion_reparto = RepartoAnimacionPoker(self, cartas_comunitarias=False)
        ANIMACION_ACTIVA = True
        
        self.mazo.repartir_carta() # Quema 1 carta (pre-flop)

    def avanzar_fase(self):
        global ANIMACION_ACTIVA
        if ANIMACION_ACTIVA: return
        
        # Transición de cartas comunitarias
        if self.fase == 'Reparto':
             self.fase = 'Pre-Flop'
             self.resultado = "Tu turno: Apuesta, Pasa o Retírate"
             return # No avanza la mesa, espera acción del jugador
             
        if self.fase == 'Pre-Flop' or self.fase == 'Flop' or self.fase == 'Turn':
            
            if self.fase == 'Pre-Flop':
                self.fase = 'Flop'
                self.resultado = "Flop: Tu turno de apuesta."
            elif self.fase == 'Flop':
                self.fase = 'Turn'
                self.resultado = "Turn: Tu turno de apuesta."
            elif self.fase == 'Turn':
                self.fase = 'River'
                self.resultado = "River: Última ronda de apuesta."
            
            # Iniciar animación de Flop, Turn o River
            self.animacion_reparto = RepartoAnimacionPoker(self, cartas_comunitarias=True)
            ANIMACION_ACTIVA = True
            self.mazo.repartir_carta() # Quema antes de repartir

        elif self.fase == 'River':
            self.fase = 'Resultado'
            self.determinar_ganador()
            
        elif self.fase == 'Resultado':
             self.jugando = False
             self.resultado = "Presiona 'Nueva Partida'"

    # --- Acciones del Jugador ---
    def accion_check_pass(self):
        if self.apuesta_actual_ronda > 0:
            self.resultado = "Debes Igualar (Call) o Retirarte (Fold)."
        else:
            self.resultado = "Pasaste (Check). Avanzando a la siguiente fase."
            self.avanzar_fase()

    def accion_call_igualar(self):
        costo = self.apuesta_actual_ronda
        if usuario_actual.deduct_balance(costo):
             self.bote += costo
             guardar_saldo_actual()
             self.resultado = f"Igualaste ({costo}€). Avanzando."
             self.avanzar_fase()
        else:
             self.resultado = "Fondos insuficientes para igualar."

    def accion_raise_subir(self, monto=50):
        costo = self.apuesta_actual_ronda + monto
        if usuario_actual.deduct_balance(costo):
            self.bote += costo
            self.apuesta_actual_ronda = costo
            guardar_saldo_actual()
            self.resultado = f"Subiste la apuesta a {costo}€."
            # Lógica de Bot Simplificada: Bot siempre iguala la subida del jugador
            self.bote += costo * 2
            self.resultado += " (Bots igualan)."
            self.avanzar_fase()
        else:
            self.resultado = "Fondos insuficientes para subir."
            
    def accion_fold_retirar(self):
        self.jugando = False
        self.resultado = "Te retiraste de la mano. Presiona 'Nueva Partida'"
        self.fase = 'Resultado'
        
    def determinar_ganador(self):
        ganador = random.choice(['Jugador', 'Bot1', 'Bot2'])
        
        if ganador == 'Jugador':
            usuario_actual.add_balance(self.bote) 
            self.resultado = f"¡Ganaste el bote de {self.bote}€! (Simulado)"
        else:
            self.resultado = f"Perdiste contra {ganador} (Simulado)"
            
        self.fase = 'Resultado'
        guardar_saldo_actual()

poker_juego = Poker()


# --- 7. LÓGICA AVANZADA DE RULETA ---

# DICIONARIO DE APUESTAS (CORRECCIÓN DE SINTAXIS)
APUESTAS_RULETA = {
    '0': 35, '1': 35, '2': 35, '3': 35, '4': 35, '5': 35, '6': 35, '7': 35, '8': 35, '9': 35, '10': 35,
    '11': 35, '12': 35, '13': 35, '14': 35, '15': 35, '16': 35, '17': 35, '18': 35, '19': 35, '20': 35,
    '21': 35, '22': 35, '23': 35, '24': 35, '25': 35, '26': 35, '27': 35, '28': 35, '29': 35, '30': 35,
    '31': 35, '32': 35, '33': 35, '34': 35, '35': 35, '36': 36,
    'ROJO': 1, 'NEGRO': 1, 'PAR': 1, 'IMPAR': 1, '1-18': 1, '19-36': 1,
    '1ST12': 2, '2ND12': 2, '3RD12': 2,
    'COL1': 2, 'COL2': 2, 'COL3': 2 
}

class Ruleta:
    # ... (Clase Ruleta omitida) ...
    def __init__(self):
        self.reiniciar()
        
    def reiniciar(self):
        global ruleta_color_fondo
        self.apuestas = {} 
        self.saldo_apuesta = 0
        self.estado = 'apuestas' 
        self.angulo = 0
        self.velocidad = 0
        self.resultado = None
        self.msg = "Coloca tus fichas y gira."
        self.btn_girar_activo = True
        ruleta_color_fondo = DORADO
        
    def apostar(self, key, valor_ficha=1):
        if self.estado != 'apuestas': return
        if not usuario_actual or not usuario_actual.balance >= FICHA_CICLO[0]:
             print("ALERTA: Saldo insuficiente para apostar.")
             return
             
        current_apuesta = self.apuestas.get(key, 0)
        
        current_index = -1
        for i, val in enumerate(FICHA_CICLO):
            if val <= current_apuesta:
                current_index = i
        
        valor_a_añadir = FICHA_CICLO[(current_index + 1) % len(FICHA_CICLO)]
        
        if current_apuesta in FICHA_CICLO:
            next_value = FICHA_CICLO[(FICHA_CICLO.index(current_apuesta) + 1) % len(FICHA_CICLO)]
            if next_value > current_apuesta:
                 valor_a_añadir = next_value - current_apuesta
            else:
                 valor_a_añadir = FICHA_CICLO[0] 
        else:
             valor_a_añadir = FICHA_CICLO[0]
        
        if usuario_actual.deduct_balance(valor_a_añadir):
            self.apuestas[key] = current_apuesta + valor_a_añadir
            self.saldo_apuesta += valor_a_añadir
            guardar_saldo_actual()

    def iniciar_giro(self):
        if self.estado != 'apuestas' or self.saldo_apuesta == 0: return
        self.estado = 'girando'
        self.velocidad = random.randint(50, 100) 
        self.msg = "¡Girando!"
        self.btn_girar_activo = False

    def pagar(self):
        if self.estado != 'pago' or self.resultado is None: return
        
        ganancia_total = 0
        apuesta_devuelta = 0
        
        numero_ganador = random.randint(0, 36)
        self.resultado = numero_ganador 

        ROJOS = {1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36}
        
        for key, apuesta_valor in self.apuestas.items():
            es_ganador = False
            multiplicador = APUESTAS_RULETA.get(key, 0)
            
            # Chequeo de Apuestas
            if type(key) is int and key == numero_ganador: es_ganador = True 
            elif key == 'PAR' and numero_ganador != 0 and numero_ganador % 2 == 0: es_ganador = True
            elif key == 'IMPAR' and numero_ganador != 0 and numero_ganador % 2 != 0: es_ganador = True
            elif key == 'ROJO' and numero_ganador in ROJOS: es_ganador = True
            elif key == 'NEGRO' and numero_ganador != 0 and numero_ganador not in ROJOS: es_ganador = True
            elif key == '1-18' and 1 <= numero_ganador <= 18: es_ganador = True
            elif key == '19-36' and 19 <= numero_ganador <= 36: es_ganador = True
            elif key == '1ST12' and 1 <= numero_ganador <= 12: es_ganador = True
            elif key == '2ND12' and 13 <= numero_ganador <= 24: es_ganador = True
            elif key == '3RD12' and 25 <= numero_ganador <= 36: es_ganador = True
            elif key == 'COL1' and numero_ganador in {1, 4, 7, 10, 13, 16, 19, 22, 25, 28, 31, 34}: es_ganador = True
            elif key == 'COL2' and numero_ganador in {2, 5, 8, 11, 14, 17, 20, 23, 26, 29, 32, 35}: es_ganador = True
            elif key == 'COL3' and numero_ganador in {3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, 36}: es_ganador = True

            
            if es_ganador:
                ganancia_total += apuesta_valor * multiplicador 
                apuesta_devuelta += apuesta_valor

        
        if ganancia_total > 0:
            usuario_actual.add_balance(ganancia_total + apuesta_devuelta) 
            self.msg = f"¡Ganó {numero_ganador}! ¡GANASTE {ganancia_total}€!"
        else:
            self.msg = f"Ganó {numero_ganador}. Perdiste {self.saldo_apuesta}€."

        self.apuestas = {}
        self.saldo_apuesta = 0
        self.estado = 'resultado_mostrado'
        guardar_saldo_actual()

ruleta_juego = Ruleta()


# --- 8. IMPLEMENTACIÓN DE TRAGAPERRAS (SLOTS) ---

class Slots:
    # ... (Clase Slots omitida) ...
    def __init__(self):
        self.simbolos = ['cherry', 'lemon', 'bell', 'bar', 'melon', 'seven']
        self.rodillos = [random.choice(self.simbolos)] * 3
        self.estado = 'espera' 
        self.resultado = ""
        self.apuesta = 25
        self.tiempo_giro = 0
        self.duracion_giro = 1.5

    def reiniciar(self):
        self.estado = 'espera'
        self.resultado = f"Apuesta {self.apuesta}€ y presiona GIRAR."
        
    def iniciar_giro(self):
        global ANIMACION_ACTIVA
        if self.estado != 'espera': return
        
        if not usuario_actual.deduct_balance(self.apuesta):
            self.resultado = "Fondos insuficientes."
            return
            
        guardar_saldo_actual()
        self.estado = 'girando'
        self.tiempo_giro = time.time()
        self.resultado = "¡Rodillos girando!"
        ANIMACION_ACTIVA = True

    def actualizar_giro(self):
        elapsed = time.time() - self.tiempo_giro
        
        if elapsed < self.duracion_giro:
            self.rodillos = [random.choice(self.simbolos) for _ in range(3)]
        else:
            self.estado = 'pago'
            global ANIMACION_ACTIVA
            ANIMACION_ACTIVA = False
            self.determinar_pago()

    def determinar_pago(self):
        r = self.rodillos
        premio = 0
        
        if r[0] == r[1] == r[2]: 
            if r[0] == 'seven': premio = self.apuesta * 20 
            elif r[0] == 'bar': premio = self.apuesta * 10 
            elif r[0] == 'cherry': premio = self.apuesta * 5 
            else: premio = self.apuesta * 3
        elif r[0] == r[1] or r[1] == r[2]: 
            premio = self.apuesta * 0.5
            
        if premio > 0:
            usuario_actual.add_balance(self.apuesta + premio) 
            self.resultado = f"¡GANASTE! +{premio:.0f}€"
        else:
            self.resultado = "Sin suerte."
            
        self.estado = 'espera'
        guardar_saldo_actual()


slots_juego = Slots()


# --- 9. FUNCIONES DE DIBUJO Y MANEJO DE PANTALLAS ---

def dibujar_ficha_apuesta(superficie, valor, x, y):
    # Determina el valor visual de la ficha basado en el valor acumulado
    valor_visual = 1 
    if valor >= 100: valor_visual = 100
    elif valor >= 25: valor_visual = 25
    elif valor >= 10: valor_visual = 10
    elif valor >= 5: valor_visual = 5
    else: valor_visual = 1 
        
    ficha_img = RECURSOS['fichas'].get(valor_visual)
    
    if ficha_img:
        superficie.blit(ficha_img, (x - FICHA_W // 2, y - FICHA_H // 2))
        
        texto_valor = FUENTE_SMALL.render(str(valor), True, NEGRO)
        superficie.blit(texto_valor, (x - texto_valor.get_width() // 2, y - texto_valor.get_height() // 2))

def dibujar_mano(superficie, mano, x_inicio, y_pos, ocultar_primera=False):
    x = x_inicio
    for i, (valor, carta_key) in enumerate(mano):
        if ocultar_primera and i == 1 and bj_juego.jugando:
            imagen = RECURSOS['back']
        else:
            imagen = RECURSOS['cartas'].get(carta_key)
            
        superficie.blit(imagen, (x, y_pos))
        x += CARTA_W + 15

# --- RUEDA GRÁFICA (DIBUJANDO LA TABLA) ---

def manejar_clic_apuesta(pos):
    # Detección de clic fuera del bucle principal
    mx, my = pos
    
    # AJUSTE DE POSICIÓN DE LA TABLA:
    X_INICIO = 50
    Y_INICIO = 450 
    NUM_W = 60
    NUM_H = 50
    
    # Solo maneja el clic si el botón izquierdo del ratón está presionado
    if pygame.mouse.get_pressed()[0] and ruleta_juego.estado == 'apuestas':
        
        # 1. Zonas 1-36
        for fila in range(3):
            for col in range(12):
                num = col * 3 + fila + 1
                x = X_INICIO + NUM_W + col * NUM_W
                y = Y_INICIO + fila * NUM_H
                rect = pygame.Rect(x, y, NUM_W, NUM_H)
                if rect.collidepoint(mx, my):
                    ruleta_juego.apostar(num, 1) 
                    return

        # 2. Zona 0
        X_ZERO = X_INICIO; Y_ZERO = Y_INICIO; W_ZERO = NUM_W; H_ZERO = NUM_H * 3
        rect_zero = pygame.Rect(X_ZERO, Y_ZERO, W_ZERO, H_ZERO)
        if rect_zero.collidepoint(mx, my): ruleta_juego.apostar(0, 1)

        # 3. Zonas Externas (Docenas, Columnas, Simples)
        
        # Docenas
        for i in range(3):
            x = X_INICIO + NUM_W + i * (NUM_W * 4); y = Y_INICIO + NUM_H * 3; W = NUM_W * 4; H = NUM_H
            rect = pygame.Rect(x, y, W, H)
            if rect.collidepoint(mx, my):
                key = ['1ST12', '2ND12', '3RD12'][i]
                ruleta_juego.apostar(key, 1)
                return
        
        # Filas (Columnas 2:1)
        for i in range(3):
            x = X_INICIO + NUM_W + 12 * NUM_W; y = Y_INICIO + i * NUM_H; W = NUM_W; H = NUM_H
            rect = pygame.Rect(x, y, W, H)
            if rect.collidepoint(mx, my):
                key = ['COL1', 'COL2', 'COL3'][i]
                ruleta_juego.apostar(key, 1)
                return
        
        # Simples (1:1)
        X_SIMPLE = X_INICIO + NUM_W
        Y_SIMPLE = Y_INICIO + NUM_H * 4
        W_SIMPLE = NUM_W * 2
        H_SIMPLE = NUM_H
        
        apuestas_simples_rects = [
            (pygame.Rect(X_SIMPLE, Y_SIMPLE, W_SIMPLE, H_SIMPLE), '1-18'), 
            (pygame.Rect(X_SIMPLE + W_SIMPLE, Y_SIMPLE, W_SIMPLE, H_SIMPLE), '19-36'), 
            (pygame.Rect(X_SIMPLE + 2 * W_SIMPLE, Y_SIMPLE, W_SIMPLE, H_SIMPLE), 'PAR'), 
            (pygame.Rect(X_SIMPLE + 3 * W_SIMPLE, Y_SIMPLE, W_SIMPLE, H_SIMPLE), 'IMPAR'), 
            (pygame.Rect(X_SIMPLE + 4 * W_SIMPLE, Y_SIMPLE, W_SIMPLE, H_SIMPLE), 'ROJO'), 
            (pygame.Rect(X_SIMPLE + 5 * W_SIMPLE, Y_SIMPLE, W_SIMPLE, H_SIMPLE), 'NEGRO')
        ]
        
        for rect, key in apuestas_simples_rects:
            if rect.collidepoint(mx, my):
                ruleta_juego.apostar(key, 1)
                return

def dibujar_tabla_ruleta(superficie):
    # Coordenadas y dimensiones de la tabla
    X_INICIO = 50
    Y_INICIO = 450 # AJUSTADO A 450
    NUM_W = 60
    NUM_H = 50
    
    ROJOS = {1, 3, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36}
    
    # 1. Dibujar Zonas 1-36
    for fila in range(3):
        for col in range(12):
            num = col * 3 + fila + 1
            
            x = X_INICIO + NUM_W + col * NUM_W
            y = Y_INICIO + fila * NUM_H
            
            color = ROJO_R if num in ROJOS else NEGRO_R
            
            rect = pygame.Rect(x, y, NUM_W, NUM_H)
            pygame.draw.rect(superficie, color, rect)
            pygame.draw.rect(superficie, BLANCO, rect, 1) 
            
            texto = FUENTE_SMALL.render(str(num), True, BLANCO)
            superficie.blit(texto, (x + NUM_W // 2 - texto.get_width() // 2, y + NUM_H // 2 - texto.get_height() // 2))
            
            if num in ruleta_juego.apuestas:
                 dibujar_ficha_apuesta(superficie, ruleta_juego.apuestas[num], x + NUM_W // 2, y + NUM_H // 2)

    # 2. Dibujar Zona 0 (Zero)
    X_ZERO = X_INICIO; Y_ZERO = Y_INICIO; W_ZERO = NUM_W; H_ZERO = NUM_H * 3
    rect_zero = pygame.Rect(X_ZERO, Y_ZERO, W_ZERO, H_ZERO)
    pygame.draw.rect(superficie, VERDE_MESA, rect_zero)
    pygame.draw.rect(superficie, BLANCO, rect_zero, 1)
    texto_zero = FUENTE_JUEGO.render("0", True, BLANCO)
    superficie.blit(texto_zero, (X_ZERO + W_ZERO // 2 - texto_zero.get_width() // 2, Y_ZERO + H_ZERO // 2 - texto_zero.get_height() // 2))
    
    if 0 in ruleta_juego.apuestas:
        dibujar_ficha_apuesta(superficie, ruleta_juego.apuestas[0], X_ZERO + W_ZERO // 2, Y_ZERO + H_ZERO // 2)

    # 3. Zonas 2:1 y 1:1 (Docenas, Columnas y Simples)
    
    # Docenas (1st 12, 2nd 12, 3rd 12)
    for i in range(3):
        x = X_INICIO + NUM_W + i * (NUM_W * 4); y = Y_INICIO + NUM_H * 3; W = NUM_W * 4; H = NUM_H
        rect = pygame.Rect(x, y, W, H)
        pygame.draw.rect(superficie, NEGRO_R, rect)
        pygame.draw.rect(superficie, BLANCO, rect, 1)
        texto = FUENTE_SMALL.render(f"{i+1}ª 12", True, BLANCO)
        superficie.blit(texto, (x + W // 2 - texto.get_width() // 2, y + H // 2 - texto.get_height() // 2))
        key = ['1ST12', '2ND12', '3RD12'][i]
        if key in ruleta_juego.apuestas: dibujar_ficha_apuesta(superficie, ruleta_juego.apuestas[key], x + W // 2, y + H // 2)


    # Filas (Columnas 2:1)
    for i in range(3):
        x = X_INICIO + NUM_W + 12 * NUM_W; y = Y_INICIO + i * NUM_H; W = NUM_W; H = NUM_H
        rect = pygame.Rect(x, y, W, H)
        pygame.draw.rect(superficie, NEGRO_R, rect)
        pygame.draw.rect(superficie, BLANCO, rect, 1)
        texto = FUENTE_SMALL.render("2:1", True, BLANCO)
        superficie.blit(texto, (x + W // 2 - texto.get_width() // 2, y + H // 2 - texto.get_height() // 2))
        key = ['COL1', 'COL2', 'COL3'][i]
        if key in ruleta_juego.apuestas: dibujar_ficha_apuesta(superficie, ruleta_juego.apuestas[key], x + W // 2, y + H // 2)

    # Apuestas Simples (Rojo/Negro, Par/Impar, Alto/Bajo)
    X_SIMPLE = X_INICIO + NUM_W
    Y_SIMPLE = Y_INICIO + NUM_H * 4
    W_SIMPLE = NUM_W * 2
    H_SIMPLE = NUM_H
    
    
    apuestas_simples = [('1-18', (0, 100, 150)), ('19-36', (0, 100, 150)), ('PAR', (0, 150, 0)), ('IMPAR', (0, 150, 0)), ('ROJO', ROJO_R), ('NEGRO', NEGRO_R)]
    
    for i, (key, color) in enumerate(apuestas_simples):
        x = X_SIMPLE + i * W_SIMPLE
        y = Y_SIMPLE
        rect = pygame.Rect(x, y, W_SIMPLE, H_SIMPLE)
        
        pygame.draw.rect(superficie, color, rect)
        pygame.draw.rect(superficie, BLANCO, rect, 1)
        
        texto = FUENTE_SMALL.render(key.replace('-', '/'), True, BLANCO)
        superficie.blit(texto, (x + W_SIMPLE // 2 - texto.get_width() // 2, y + H_SIMPLE // 2 - texto.get_height() // 2))

        if key in ruleta_juego.apuestas: dibujar_ficha_apuesta(superficie, ruleta_juego.apuestas[key], x + W_SIMPLE // 2, y + H_SIMPLE // 2)

def pantalla_login():
    # Nueva pantalla obligatoria de login/registro
    VENTANA.fill(NEGRO)
    
    titulo_texto = FUENTE_TITULO.render("~Casino Uax~", True, DORADO)
    VENTANA.blit(titulo_texto, (ANCHO // 2 - titulo_texto.get_width() // 2, 100))
    
    # Casillas de Entrada (Inicializadas en main)
    global user_box_login, pass_box_login, login_message

    # 1. Etiquetas
    lbl_user = FUENTE_JUEGO.render("Usuario:", True, BLANCO)
    VENTANA.blit(lbl_user, (ANCHO // 2 - 300, 300))
    
    lbl_pass = FUENTE_JUEGO.render("Contraseña:", True, BLANCO)
    VENTANA.blit(lbl_pass, (ANCHO // 2 - 300, 380))
    
    # 2. Dibujar Casillas
    user_box_login.draw(VENTANA)
    pass_box_login.draw(VENTANA)
    
    # 3. Lógica de Botones (Usando las casillas de texto)
    
    def intentar_acceso():
        global login_message
        username = user_box_login.text
        password = pass_box_login.text
        
        success, msg = iniciar_sesion(username, password)
        login_message = msg
        
        if success:
             set_usuario_actual(username)
             ir_a_menu()

    def intentar_registro():
        global login_message
        username = user_box_login.text
        password = pass_box_login.text
        
        if len(username) < 3 or len(password) < 4:
            login_message = "Error: Usuario/Contraseña demasiado cortos."
            return

        success, msg = registrar_usuario(username, password)
        login_message = msg
        
        if success:
             set_usuario_actual(username)
             ir_a_menu()

    # Mensaje de estado (éxito/error)
    msg_status = FUENTE_JUEGO.render(login_message, True, ROJO_BTN if 'Error' in login_message or 'denegado' in login_message or 'demasiado' in login_message else DORADO)
    VENTANA.blit(msg_status, (ANCHO // 2 - msg_status.get_width() // 2, 450))

    # Botones
    btn_login = Boton(ANCHO // 2 - 200, 550, 200, 60, VERDE_BTN, (0, 200, 0), "Iniciar Sesión", intentar_acceso, font=FUENTE_JUEGO)
    btn_register = Boton(ANCHO // 2 + 20, 550, 200, 60, (0, 100, 150), (0, 120, 180), "Registrarse", intentar_registro, font=FUENTE_JUEGO)
    
    btn_login.dibujar(VENTANA)
    btn_register.dibujar(VENTANA)
    
    # Retorna los objetos de botones (los textboxes ya son globales y se manejan en main)
    return [btn_login, btn_register]


def pantalla_menu():
    # ... (Implementación omitida) ...
    VENTANA.blit(RECURSOS['fondo_menu'], (0, 0))
    
    s = pygame.Surface((ANCHO, ALTO), pygame.SRCALPHA)
    s.fill((0, 0, 0, 150)) 
    VENTANA.blit(s, (0, 0))

    if usuario_actual:
        if usuario_actual.isAdmin:
             titulo_texto = FUENTE_TITULO.render("Owner (Modo Dios)", True, ROJO_BTN)
             balance_texto = FUENTE_MENU.render(f"Fondos: {usuario_actual.balance:,.2f} €", True, BLANCO)
        else:
            titulo_texto = FUENTE_TITULO.render(f"Bienvenido, {usuario_actual.username}!", True, DORADO)
            balance_texto = FUENTE_MENU.render(f"Saldo: {usuario_actual.balance:,.2f} €", True, BLANCO)
             
        VENTANA.blit(titulo_texto, (ANCHO // 2 - titulo_texto.get_width() // 2, 100))
        VENTANA.blit(balance_texto, (ANCHO // 2 - balance_texto.get_width() // 2, 180))

    
    centro_x = ANCHO // 2
    centro_y = ALTO // 2
    espacio = 200
    
    botones_menu = [
        Boton(centro_x - espacio - 100, centro_y - 75, 300, 100, VERDE_BTN, (0, 200, 0), "Blackjack 21", ir_a_blackjack),
        Boton(centro_x + 100, centro_y - 75, 300, 100, VERDE_BTN, (0, 200, 0), "Póker (vs BOT)", ir_a_poker),
        Boton(centro_x - espacio - 100, centro_y + 75, 300, 100, VERDE_BTN, (0, 200, 0), "Ruleta", ir_a_ruleta),
        Boton(centro_x + 100, centro_y + 75, 300, 100, VERDE_BTN, (0, 200, 0), "Tragaperras", ir_a_tragaperras),
        Boton(ANCHO - 130, 20, 100, 40, ROJO_BTN, (255, 0, 0), "Salir", ir_a_login, font=FUENTE_JUEGO),
        Boton(20, ANCHO - 130, 200, 40, (0, 100, 150), (0, 120, 180), "+ Depositar 100€", depositar_dinero_demo, font=FUENTE_SMALL)
    ]
    
    for boton in botones_menu:
        boton.dibujar(VENTANA)
        
    return botones_menu


def pantalla_blackjack():
    # ... (Implementación omitida) ...
    VENTANA.blit(RECURSOS['fondo_blackjack'], (0, 0))
    
    dibujar_mano(VENTANA, bj_juego.crupier, 150, 80, ocultar_primera=True)
    dibujar_mano(VENTANA, bj_juego.jugador, 150, 280, ocultar_primera=False)

    if bj_juego.animacion_reparto:
        bj_juego.animacion_reparto.dibujar(VENTANA)
        
    saldo_texto = FUENTE_MENU.render(f"Saldo: {usuario_actual.balance:,.2f} € | Apuesta: {bj_juego.apuesta} €", True, BLANCO)
    VENTANA.blit(saldo_texto, (ANCHO // 2 - saldo_texto.get_width() // 2, 10))
    
    texto_crupier = FUENTE_JUEGO.render("Crupier:", True, BLANCO)
    VENTANA.blit(texto_crupier, (50, 110))
    if not bj_juego.jugando:
        p_crupier = calcular_puntuacion(bj_juego.crupier)
        p_crupier_texto = FUENTE_JUEGO.render(f"Total: {p_crupier}", True, BLANCO)
        VENTANA.blit(p_crupier_texto, (ANCHO // 2, 110))
    
    texto_jugador = FUENTE_JUEGO.render("Jugador:", True, BLANCO)
    VENTANA.blit(texto_jugador, (50, 310))
    p_jugador = calcular_puntuacion(bj_juego.jugador)
    p_jugador_texto = FUENTE_JUEGO.render(f"Total: {p_jugador}", True, BLANCO)
    VENTANA.blit(p_jugador_texto, (ANCHO // 2, 310))
    
    resultado_texto = FUENTE_MENU.render(bj_juego.resultado, True, DORADO)
    VENTANA.blit(resultado_texto, (ANCHO // 2 - resultado_texto.get_width() // 2, 500))
    
    btn_pedir = Boton(300, 650, 150, 60, VERDE_BTN, (0, 200, 0), "Pedir Carta", bj_juego.pedir_carta, font=FUENTE_JUEGO)
    btn_plantarse = Boton(550, 650, 150, 60, ROJO_BTN, (255, 0, 0), "Plantarse", bj_juego.plantarse, font=FUENTE_JUEGO)
    btn_nueva = Boton(900, 10, 180, 50, VERDE_BTN, (0, 200, 0), "Nueva Partida", bj_juego.nueva_partida, font=FUENTE_JUEGO)
    
    if not bj_juego.jugando or ANIMACION_ACTIVA:
        btn_pedir.color_normal = GRIS_BTN; btn_pedir.color_hover = GRIS_BTN
        btn_plantarse.color_normal = GRIS_BTN; btn_plantarse.color_hover = GRIS_BTN

    btn_pedir.dibujar(VENTANA)
    btn_plantarse.dibujar(VENTANA)
    btn_nueva.dibujar(VENTANA)
    boton_volver_menu.dibujar(VENTANA)

    return [btn_pedir, btn_plantarse, btn_nueva, boton_volver_menu]

def pantalla_poker():
    # ... (Implementación omitida) ...
    VENTANA.blit(RECURSOS['fondo_poker'], (0, 0))
    
    titulo_texto = FUENTE_TITULO.render("Póker Texas Hold'em (vs Bots)", True, DORADO)
    VENTANA.blit(titulo_texto, (ANCHO // 2 - titulo_texto.get_width() // 2, 50))
    
    bote_texto = FUENTE_MENU.render(f"Bote: {poker_juego.bote} € | Apuesta Mín: {poker_juego.apuesta_actual_ronda} €", True, BLANCO)
    VENTANA.blit(bote_texto, (ANCHO // 2 - bote_texto.get_width() // 2, 120))
    
    # 1. Cartas Comunitarias (Revelación Progresiva)
    start_x = ANCHO // 2 - 5 * (CARTA_W + 15) / 2
    num_reveladas = 0
    if poker_juego.fase == 'Flop': num_reveladas = 3
    elif poker_juego.fase == 'Turn': num_reveladas = 4
    elif poker_juego.fase == 'River' or poker_juego.fase == 'Resultado': num_reveladas = 5

    for i in range(5):
        if i < len(poker_juego.comunitarias) and i < num_reveladas:
            (valor, key) = poker_juego.comunitarias[i]
            VENTANA.blit(RECURSOS['cartas'][key], (start_x + i * (CARTA_W + 15), 250))
        else:
            VENTANA.blit(RECURSOS['back'], (start_x + i * (CARTA_W + 15), 250))


    # 2. Mano del Jugador (Abiertas)
    p_jugador_x = ANCHO // 2 - len(poker_juego.manos['Jugador']) * (CARTA_W + 15) / 2
    for i, (valor, key) in enumerate(poker_juego.manos['Jugador']):
        VENTANA.blit(RECURSOS['cartas'][key], (p_jugador_x + i * (CARTA_W + 15), 550))
    
    # 3. Manos de los Bots (Cerradas)
    for i in range(2): VENTANA.blit(RECURSOS['back'], (50 + i * 20, 250)) # Bot 1
    for i in range(2): VENTANA.blit(RECURSOS['back'], (ANCHO - 50 - 2*CARTA_W + i * 20, 250)) # Bot 2
        
    
    # 4. Mensaje de Resultado
    resultado_texto = FUENTE_MENU.render(poker_juego.resultado, True, DORADO)
    VENTANA.blit(resultado_texto, (ANCHO // 2 - resultado_texto.get_width() // 2, 450))

    # 5. Botones de Control de Fase y Acciones
    botones = []
    
    if poker_juego.jugando:
        
        botones.append(Boton(ANCHO // 2 - 300, 700, 150, 50, VERDE_BTN, (0, 200, 0), "Check / Call", poker_juego.accion_call_igualar, font=FUENTE_JUEGO))
        botones.append(Boton(ANCHO // 2 - 140, 700, 150, 50, (0, 100, 150), (0, 120, 180), "Subir (50€)", lambda: poker_juego.accion_raise_subir(50), font=FUENTE_JUEGO))
        botones.append(Boton(ANCHO // 2 + 20, 700, 150, 50, ROJO_BTN, (255, 0, 0), "Retirarse", poker_juego.accion_fold_retirar, font=FUENTE_JUEGO))
        
        if poker_juego.apuesta_actual_ronda == 0 and poker_juego.fase != 'Reparto':
             botones.append(Boton(ANCHO // 2 + 180, 700, 150, 50, GRIS_BTN, (120, 120, 120), "Pasar", poker_juego.avanzar_fase, font=FUENTE_JUEGO))
             
        if poker_juego.fase == 'Reparto':
             botones.append(Boton(ANCHO // 2 + 180, 700, 150, 50, VERDE_BTN, (0, 200, 0), "Continuar", poker_juego.avanzar_fase, font=FUENTE_JUEGO))
        

    else:
        btn_nueva = Boton(ANCHO // 2 - 150, 700, 300, 50, VERDE_BTN, (0, 200, 0), "Nueva Partida (100€)", poker_juego.nueva_partida, font=FUENTE_JUEGO)
        botones.append(btn_nueva)

    botones.append(boton_volver_menu)
    for btn in botones: btn.dibujar(VENTANA)
    return botones

def pantalla_ruleta():
    # ... (Implementación omitida) ...
    global ruleta_angulo, ruleta_velocidad, ruleta_msg, ruleta_color_fondo 

    VENTANA.blit(RECURSOS['fondo_ruleta'], (0, 0)) # FONDO DE RULETA
    
    # 1. Dibujar Rueda (AJUSTADA LA POSICIÓN ARRIBA)
    rueda_img = RECURSOS['ruleta_wheel']
    rotated_wheel = pygame.transform.rotate(rueda_img, ruleta_juego.angulo)
    wheel_rect = rotated_wheel.get_rect(center=(300, 250)) # AJUSTE Y = 250
    VENTANA.blit(rotated_wheel, wheel_rect)
    pygame.draw.polygon(VENTANA, DORADO, [(300, 70), (290, 90), (310, 90)]) # Marcador ajustado

    # 2. Dibujar TABLERO DE APUESTAS (GRÁFICOS DIBUJADOS)
    dibujar_tabla_ruleta(VENTANA)
    
    # 3. Lógica de Giro
    if ruleta_juego.estado == 'girando':
        ruleta_juego.angulo += ruleta_juego.velocidad
        ruleta_juego.velocidad -= 0.5
        if ruleta_juego.velocidad <= 0:
            ruleta_juego.velocidad = 0
            ruleta_juego.estado = 'pago'
            ruleta_juego.pagar()

    # 4. Interfaz
    msg_texto = FUENTE_MENU.render(ruleta_juego.msg, True, DORADO)
    VENTANA.blit(msg_texto, (ANCHO // 2 - msg_texto.get_width() // 2, 50))
    
    saldo_texto = FUENTE_JUEGO.render(f"Saldo: {usuario_actual.balance:,.2f} € | Apuestas: {ruleta_juego.saldo_apuesta} €", True, BLANCO)
    VENTANA.blit(saldo_texto, (ANCHO - 350, 20))
    
    # Botones
    btn_girar = Boton(ANCHO // 2 + 100, 340, 200, 40, ROJO_BTN, (255, 0, 0), "GIRAR", ruleta_juego.iniciar_giro, font=FUENTE_JUEGO)
    btn_reiniciar = Boton(ANCHO // 2 - 150, 340, 250, 40, VERDE_BTN, (0, 200, 0), "Limpiar Apuestas", ruleta_juego.reiniciar, font=FUENTE_JUEGO)

    botones = [btn_girar, btn_reiniciar, boton_volver_menu]

    if ruleta_juego.estado != 'apuestas':
        btn_girar.color_normal = GRIS_BTN
        
    for btn in botones: btn.dibujar(VENTANA)
    
    return botones

def pantalla_tragaperras():
    # ... (Implementación omitida) ...
    VENTANA.fill((100, 100, 100))
    titulo_texto = FUENTE_TITULO.render("Tragaperras (Slots)", True, DORADO)
    VENTANA.blit(titulo_texto, (ANCHO // 2 - titulo_texto.get_width() // 2, 100))

    rodillos_y = 300
    ancho_rodillo = 180 
    espacio = 30
    x_pos = [ANCHO // 2 - ancho_rodillo * 1.5 - espacio * 1.5, ANCHO // 2 - ancho_rodillo / 2, ANCHO // 2 + ancho_rodillo / 2 + espacio]

    for i, x in enumerate(x_pos):
        rodillo_rect = pygame.Rect(x, rodillos_y, ancho_rodillo, ancho_rodillo)
        pygame.draw.rect(VENTANA, NEGRO, rodillo_rect, border_radius=15)
        pygame.draw.rect(VENTANA, (50, 50, 50), rodillo_rect.inflate(-5, -5), border_radius=15)
        
        simbolo_key = slots_juego.rodillos[i]
        simbolo_img = RECURSOS['slots'].get(simbolo_key)
        
        if simbolo_img:
             VENTANA.blit(simbolo_img, (x + ancho_rodillo // 2 - 50, rodillos_y + ancho_rodillo // 2 - 50))

    saldo_texto = FUENTE_JUEGO.render(f"Saldo: {usuario_actual.balance:,.2f} €", True, BLANCO)
    VENTANA.blit(saldo_texto, (ANCHO - 250, 20))
    
    msg_texto = FUENTE_MENU.render(slots_juego.resultado, True, DORADO)
    VENTANA.blit(msg_texto, (ANCHO // 2 - msg_texto.get_width() // 2, 600))
    
    btn_girar = Boton(ANCHO // 2 - 100, 700, 200, 60, ROJO_BTN, (255, 0, 0), f"GIRAR ({slots_juego.apuesta}€)", slots_juego.iniciar_giro, font=FUENTE_JUEGO)
    
    if slots_juego.estado == 'girando':
        btn_girar.color_normal = GRIS_BTN; btn_girar.color_hover = GRIS_BTN

    btn_girar.dibujar(VENTANA)
    boton_volver_menu.dibujar(VENTANA)
    return [btn_girar, boton_volver_menu]

# --- 10. BUCLE PRINCIPAL DEL JUEGO ---

def main():
    global estado_juego, ANIMACION_ACTIVA
    global user_box_login, pass_box_login, login_message # Habilitar acceso global a las casillas de texto
    
    ejecutando = True
    botones_activos = []

    # INICIALIZACIÓN DE CASILLAS DE TEXTO (para evitar NameError en el bucle)
    user_box_login = TextBox(ANCHO // 2 - 100, 290, 300, 40)
    pass_box_login = TextBox(ANCHO // 2 - 100, 370, 300, 40)
    pass_box_login.set_password_mode(True)
    login_message = "Ingresa tu usuario y contraseña"

    cargar_usuarios()
    
    while ejecutando:
        # Manejo de eventos (clics, teclado, cerrar ventana)
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                ejecutando = False
            
            # --- MANEJO ESPECÍFICO DE ENTRADA DE TEXTO EN LOGIN ---
            if estado_juego == 'login':
                user_box_login.handle_event(evento)
                pass_box_login.handle_event(evento)
            # ----------------------------------------------------

            # Manejo de clic de ratón (botones y tablero de ruleta)
            if evento.type == pygame.MOUSEBUTTONDOWN and evento.button == 1:
                # 1. Botones
                for boton in botones_activos:
                    if isinstance(boton, Boton) and boton.clic(evento):
                        break
                
                # 2. Ruleta Clic (Solo si está en la fase de apuestas)
                if estado_juego == 'ruleta' and ruleta_juego.estado == 'apuestas':
                    manejar_clic_apuesta(evento.pos)


        if estado_juego == 'login':
            # La función pantalla_login dibuja y gestiona las casillas/botones de login
            botones_activos = pantalla_login() 
        elif estado_juego == 'menu':
            botones_activos = pantalla_menu()
        elif estado_juego == 'blackjack':
            if ANIMACION_ACTIVA and bj_juego.animacion_reparto:
                bj_juego.animacion_reparto.actualizar()
            botones_activos = pantalla_blackjack()
        elif estado_juego == 'poker':
            if ANIMACION_ACTIVA and poker_juego.animacion_reparto:
                poker_juego.animacion_reparto.actualizar()
            botones_activos = pantalla_poker()
        elif estado_juego == 'ruleta':
            if ruleta_juego.estado == 'girando':
                ruleta_juego.angulo += ruleta_juego.velocidad
                ruleta_juego.velocidad -= 0.5
                if ruleta_juego.velocidad <= 0:
                    ruleta_juego.velocidad = 0
                    ruleta_juego.estado = 'pago'
                    ruleta_juego.pagar()

            botones_activos = pantalla_ruleta()
        elif estado_juego == 'tragaperras':
            if slots_juego.estado == 'girando':
                slots_juego.actualizar_giro()
            botones_activos = pantalla_tragaperras()
            
        pygame.display.flip()
        clock.tick(60)

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()